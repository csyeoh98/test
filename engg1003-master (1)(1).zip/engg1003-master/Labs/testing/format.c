#include <stdio.h>

int main() {
	char a = 1,b = 2,c = 3;
	printf("%d\n", b);
	return 0;
}
