#include <stdio.h>

int main() {
	int x;
	printf("Enter an integer: ");
	scanf("%f", &x);
	printf("You entered: %d\n", x);
	return 0;
}
